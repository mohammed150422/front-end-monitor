I used the grid to be able to design the page as required and I added some elements inside the sections so that I could format them as required
I created a special css file to facilitate the process of formatting inside the file
I used the h3 and h5 element to easily control the font size
I used img to add the image inside each section and added a border-radius to make the image circular